import React, { useState } from 'react';

function MoodForm() {
  const [mood, setMood] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    alert(`Mood logged: ${mood}`);
    setMood('');
  };

  return (
    <form onSubmit={handleSubmit}>
      <input type='text' value={mood} onChange={(e) => setMood(e.target.value)} placeholder='How do you feel today?' />
      <button type='submit'>Log Mood</button>
    </form>
  );
}

export default MoodForm;
