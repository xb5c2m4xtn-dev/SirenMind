from flask import Blueprint, request, jsonify

mood_bp = Blueprint('mood_bp', __name__)

@mood_bp.route('/', methods=['POST'])
def log_mood():
    data = request.get_json()
    return jsonify({'message': 'Mood logged', 'data': data})
