# Placeholder for mood model
class Mood:
    def __init__(self, date, mood_text):
        self.date = date
        self.mood_text = mood_text
