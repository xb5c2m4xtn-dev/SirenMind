# Siren Mind

**Personalized Mental Health Monitoring & Alerts**

## Project Overview
Siren Mind is your AI-powered companion for understanding your emotional patterns. Track your moods, analyze journal entries, and receive early alerts about potential mental health risks.

## Features
- Mood Tracker: Log daily moods
- Sentiment Analysis: Analyze entries for stress or anxiety
- Alerts: Notifications for concerning trends
- Visualizations: Graph mood patterns over time

## Tech Stack
- Frontend: React.js
- Backend: Python Flask
- Database: MongoDB (optional)
- AI/ML: Python (basic sentiment analysis starter)

## Getting Started
1. Clone the repository
2. Install backend and frontend dependencies
3. Start backend: `python backend/app.py`
4. Start frontend: `npm start` in `frontend/`
